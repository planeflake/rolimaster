---
type: index
system: Rolemaster
---

# Rolemaster Spell Master Index

## Channeling

### Cleric
- [[Communal Ways]]
- [[Protections]]
- [[Summons]]
- [[Life Mastery]]

### Healer
- [[Blood Ways]]
- [[Muscle Ways]]
- [[Bone Ways]]
- [[Surface Ways]]

### Animist
- [[Nature's Movement]]
- [[Plant Mastery]]
- [[Animal Mastery]]
- [[Herb Mastery]]
- [[Nature's Protection]]
- [[Nature's Lore]]

### Ranger
- [[Moving Ways]]
- [[Inner Walls]]
- [[Nature's Ways]]
- [[Path Mastery]]
- [[Nature's Guises]]

### Evil Cleric
- [[Disease]]
- [[Curses]]
- [[Necromancy]]
- [[Dark Channels]]
- [[Dark Lore]]

### Astrologer
- [[Way of the Voice]]
- [[Holy Vision]]
- [[Far Voice]]
- [[Starsense]]
- [[Time's Bridge]]
- [[Starlights]]

## Essence

### Open Essence
- [[Essence Hand]]
- [[Essence's Perceptions]]
- [[Rune Mastery]]
- [[Spell Wall]]
- [[Lesser Illusions]]
- [[Detecting Ways]]
- [[Unbarring Ways]]
- [[Physical Enhancement]]
- [[Elemental Shields]]
- [[Delving Ways]]

### Closed Essence
- [[Invisible Ways]]
- [[Living Change]]
- [[Spirit Mastery]]
- [[Spell Reins]]
- [[Lofty Bridge]]
- [[Spell Enhancement]]
- [[Gate Mastery]]
- [[Dispelling Ways]]
- [[Rapid Ways]]
- [[Shield Mastery]]

### Magician
- [[Fire Law]]
- [[Earth Law]]
- [[Light Law]]
- [[Ice Law]]
- [[Water Law]]
- [[Wind Law]]

### Illusionist
- [[Guises]]
- [[Mind Sense Molding]]
- [[Illusion Mastery]]
- [[Light Molding]]
- [[Sound Molding]]
- [[Feel-Taste-Smell]]

### Alchemist
- [[Enchanting Ways]]
- [[Organic Skills]]
- [[Inorganic Skills]]
- [[Liquid-Gas Skills]]
- [[Essence Imbedding]]
- [[Ment-Chan. Imbedding]]

### Monk
- [[Evasions]]
- [[Monk's Sense]]
- [[Body Reins]]
- [[Body Renewal]]
- [[Monk's Bridge]]

### Evil Magician
- [[Matter Disruption]]
- [[Darkness]]
- [[Dark Contacts]]
- [[Physical Erosion]]
- [[Dark Summons]]

### Sorcerer
- [[Soul Destruction]]
- [[Fluid Destruction]]
- [[Solid Destruction]]
- [[Mind Destruction]]
- [[Flesh Destruction]]
- [[Gas Destruction]]

## Mentalism

### Open Mentalism
- [[Delving]]
- [[Damage Resistance]]
- [[Cloaking]]
- [[Brilliance]]
- [[Anticipations]]
- [[Attack Avoidance]]
- [[Detections]]
- [[Illusions]]
- [[Self Healing]]
- [[Spell Resistance]]

### Closed Mentalism
- [[Mind Mastery]]
- [[Sense Mastery]]
- [[Solid Manipulation]]
- [[Liquid Manipulation]]
- [[Gas Manipulation]]
- [[Shifting]]
- [[Telekinesis]]
- [[Movement]]
- [[Mind's Door]]
- [[Speed]]

### Mentalist
- [[Mind Control]]
- [[Sense Control]]
- [[Mind Attack]]
- [[Presence]]
- [[Mind Speech]]
- [[Mind Merge]]

### Seer
- [[True Sight]]
- [[True Perception]]
- [[Mind Visions]]
- [[Sense Through Others]]
- [[Past Visions]]
- [[Future Visions]]

### Lay Healer
- [[Blood Mastery]]
- [[Muscle Mastery]]
- [[Bone Mastery]]
- [[Concussion Mastery]]
- [[Nerve and Organ Mastery]]
- [[Prosthetics]]

### Bard
- [[Controlling Songs]]
- [[Sound Projection]]
- [[Sound Control]]
- [[Sound Lore]]
- [[Lores]]
- [[Item Lore]]

### Evil Mentalist
- [[Mind Subversion]]
- [[Mind Domination]]
- [[Mind Erosion]]
- [[Mind Death]]
- [[Mind Disease]]

### Mystic
- [[Confusing Ways]]
- [[Hiding]]
- [[Mystical Change]]
- [[Liquid Alteration]]
- [[Solid Alteration]]
- [[Gas Alteration]]

