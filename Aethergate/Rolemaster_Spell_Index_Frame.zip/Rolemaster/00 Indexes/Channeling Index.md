---
type: index
realm: Channeling
system: Rolemaster
---

# Channeling Index

- [[Communal Ways]]
- [[Protections]]
- [[Summons]]
- [[Life Mastery]]
- [[Blood Ways]]
- [[Muscle Ways]]
- [[Bone Ways]]
- [[Surface Ways]]
- [[Nature's Movement]]
- [[Plant Mastery]]
- [[Animal Mastery]]
- [[Herb Mastery]]
- [[Nature's Protection]]
- [[Nature's Lore]]
- [[Moving Ways]]
- [[Inner Walls]]
- [[Nature's Ways]]
- [[Path Mastery]]
- [[Nature's Guises]]
- [[Disease]]
- [[Curses]]
- [[Necromancy]]
- [[Dark Channels]]
- [[Dark Lore]]
- [[Way of the Voice]]
- [[Holy Vision]]
- [[Far Voice]]
- [[Starsense]]
- [[Time's Bridge]]
- [[Starlights]]