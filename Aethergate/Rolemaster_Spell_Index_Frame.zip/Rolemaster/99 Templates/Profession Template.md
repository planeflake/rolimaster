---
type: profession
profession:
realm:
system: Rolemaster
tags: [rolemaster, profession]
---

# {{title}}

## Realm

## Spell Lists

## Campaign Notes
