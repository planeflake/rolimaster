---
type: spell-list
name: "Soul Destruction"
realm: Essence
profession: "Sorcerer"
list_type: "Base List"
system: Rolemaster
status: skeleton
tags: [rolemaster, spell-list, essence]
---

# Soul Destruction

## Summary

TODO: Add summary for this spell list.

## Realm

- [[Essence]]

## Profession / Category

- [[Sorcerer]]

## Spell Progression

| Level | Spell | Notes |
|---:|---|---|
| 1 | TODO |  |
| 2 | TODO |  |
| 3 | TODO |  |
| 4 | TODO |  |
| 5 | TODO |  |
| 6 | TODO |  |
| 7 | TODO |  |
| 8 | TODO |  |
| 9 | TODO |  |
| 10 | TODO |  |

## Campaign Availability

| Region / City | Availability | Notes |
|---|---|---|
| [[Aethergate]] | TODO |  |
| [[Ashfall]] | TODO |  |
| [[Mindreach]] | TODO |  |
| [[Solspire]] | TODO |  |

## Related

- [[Spell Master Index]]
