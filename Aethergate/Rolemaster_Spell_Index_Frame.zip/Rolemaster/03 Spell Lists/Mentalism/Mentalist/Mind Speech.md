---
type: spell-list
name: "Mind Speech"
realm: Mentalism
profession: "Mentalist"
list_type: "Base List"
system: Rolemaster
status: skeleton
tags: [rolemaster, spell-list, mentalism]
---

# Mind Speech

## Summary

TODO: Add summary for this spell list.

## Realm

- [[Mentalism]]

## Profession / Category

- [[Mentalist]]

## Spell Progression

| Level | Spell | Notes |
|---:|---|---|
| 1 | TODO |  |
| 2 | TODO |  |
| 3 | TODO |  |
| 4 | TODO |  |
| 5 | TODO |  |
| 6 | TODO |  |
| 7 | TODO |  |
| 8 | TODO |  |
| 9 | TODO |  |
| 10 | TODO |  |

## Campaign Availability

| Region / City | Availability | Notes |
|---|---|---|
| [[Aethergate]] | TODO |  |
| [[Ashfall]] | TODO |  |
| [[Mindreach]] | TODO |  |
| [[Solspire]] | TODO |  |

## Related

- [[Spell Master Index]]
