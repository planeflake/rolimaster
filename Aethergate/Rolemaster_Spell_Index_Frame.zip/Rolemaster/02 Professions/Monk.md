---
type: profession
profession: "Monk"
realm: Essence
system: Rolemaster
tags: [rolemaster, profession, essence]
---

# Monk

## Realm

- [[Essence]]

## Spell Lists

- [[Evasions]]
- [[Monk's Sense]]
- [[Body Reins]]
- [[Body Renewal]]
- [[Monk's Bridge]]

## Mana World Notes

TODO: Add how Monk fits into Aethergate and the mana-rationing world.
