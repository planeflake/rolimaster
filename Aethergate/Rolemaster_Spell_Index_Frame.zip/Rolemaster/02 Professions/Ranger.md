---
type: profession
profession: "Ranger"
realm: Channeling
system: Rolemaster
tags: [rolemaster, profession, channeling]
---

# Ranger

## Realm

- [[Channeling]]

## Spell Lists

- [[Moving Ways]]
- [[Inner Walls]]
- [[Nature's Ways]]
- [[Path Mastery]]
- [[Nature's Guises]]

## Mana World Notes

TODO: Add how Ranger fits into Aethergate and the mana-rationing world.
