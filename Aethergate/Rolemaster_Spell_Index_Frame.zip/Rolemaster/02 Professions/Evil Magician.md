---
type: profession
profession: "Evil Magician"
realm: Essence
system: Rolemaster
tags: [rolemaster, profession, essence]
---

# Evil Magician

## Realm

- [[Essence]]

## Spell Lists

- [[Matter Disruption]]
- [[Darkness]]
- [[Dark Contacts]]
- [[Physical Erosion]]
- [[Dark Summons]]

## Mana World Notes

TODO: Add how Evil Magician fits into Aethergate and the mana-rationing world.
