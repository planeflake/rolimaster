---
type: profession
profession: "Healer"
realm: Channeling
system: Rolemaster
tags: [rolemaster, profession, channeling]
---

# Healer

## Realm

- [[Channeling]]

## Spell Lists

- [[Blood Ways]]
- [[Muscle Ways]]
- [[Bone Ways]]
- [[Surface Ways]]

## Mana World Notes

TODO: Add how Healer fits into Aethergate and the mana-rationing world.
