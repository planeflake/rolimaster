---
type: profession
profession: "Illusionist"
realm: Essence
system: Rolemaster
tags: [rolemaster, profession, essence]
---

# Illusionist

## Realm

- [[Essence]]

## Spell Lists

- [[Guises]]
- [[Mind Sense Molding]]
- [[Illusion Mastery]]
- [[Light Molding]]
- [[Sound Molding]]
- [[Feel-Taste-Smell]]

## Mana World Notes

TODO: Add how Illusionist fits into Aethergate and the mana-rationing world.
