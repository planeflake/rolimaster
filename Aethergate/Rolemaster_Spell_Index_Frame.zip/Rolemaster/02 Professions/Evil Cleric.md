---
type: profession
profession: "Evil Cleric"
realm: Channeling
system: Rolemaster
tags: [rolemaster, profession, channeling]
---

# Evil Cleric

## Realm

- [[Channeling]]

## Spell Lists

- [[Disease]]
- [[Curses]]
- [[Necromancy]]
- [[Dark Channels]]
- [[Dark Lore]]

## Mana World Notes

TODO: Add how Evil Cleric fits into Aethergate and the mana-rationing world.
