---
type: profession
profession: "Cleric"
realm: Channeling
system: Rolemaster
tags: [rolemaster, profession, channeling]
---

# Cleric

## Realm

- [[Channeling]]

## Spell Lists

- [[Communal Ways]]
- [[Protections]]
- [[Summons]]
- [[Life Mastery]]

## Mana World Notes

TODO: Add how Cleric fits into Aethergate and the mana-rationing world.
