---
type: profession
profession: "Alchemist"
realm: Essence
system: Rolemaster
tags: [rolemaster, profession, essence]
---

# Alchemist

## Realm

- [[Essence]]

## Spell Lists

- [[Enchanting Ways]]
- [[Organic Skills]]
- [[Inorganic Skills]]
- [[Liquid-Gas Skills]]
- [[Essence Imbedding]]
- [[Ment-Chan. Imbedding]]

## Mana World Notes

TODO: Add how Alchemist fits into Aethergate and the mana-rationing world.
