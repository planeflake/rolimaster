---
type: profession
profession: "Mentalist"
realm: Mentalism
system: Rolemaster
tags: [rolemaster, profession, mentalism]
---

# Mentalist

## Realm

- [[Mentalism]]

## Spell Lists

- [[Mind Control]]
- [[Sense Control]]
- [[Mind Attack]]
- [[Presence]]
- [[Mind Speech]]
- [[Mind Merge]]

## Mana World Notes

TODO: Add how Mentalist fits into Aethergate and the mana-rationing world.
