---
type: profession
profession: "Lay Healer"
realm: Mentalism
system: Rolemaster
tags: [rolemaster, profession, mentalism]
---

# Lay Healer

## Realm

- [[Mentalism]]

## Spell Lists

- [[Blood Mastery]]
- [[Muscle Mastery]]
- [[Bone Mastery]]
- [[Concussion Mastery]]
- [[Nerve and Organ Mastery]]
- [[Prosthetics]]

## Mana World Notes

TODO: Add how Lay Healer fits into Aethergate and the mana-rationing world.
