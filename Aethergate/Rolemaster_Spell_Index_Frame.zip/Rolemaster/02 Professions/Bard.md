---
type: profession
profession: "Bard"
realm: Mentalism
system: Rolemaster
tags: [rolemaster, profession, mentalism]
---

# Bard

## Realm

- [[Mentalism]]

## Spell Lists

- [[Controlling Songs]]
- [[Sound Projection]]
- [[Sound Control]]
- [[Sound Lore]]
- [[Lores]]
- [[Item Lore]]

## Mana World Notes

TODO: Add how Bard fits into Aethergate and the mana-rationing world.
