---
type: profession
profession: "Magician"
realm: Essence
system: Rolemaster
tags: [rolemaster, profession, essence]
---

# Magician

## Realm

- [[Essence]]

## Spell Lists

- [[Fire Law]]
- [[Earth Law]]
- [[Light Law]]
- [[Ice Law]]
- [[Water Law]]
- [[Wind Law]]

## Mana World Notes

TODO: Add how Magician fits into Aethergate and the mana-rationing world.
