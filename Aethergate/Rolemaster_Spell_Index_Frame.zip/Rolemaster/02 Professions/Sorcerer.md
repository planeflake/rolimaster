---
type: profession
profession: "Sorcerer"
realm: Essence
system: Rolemaster
tags: [rolemaster, profession, essence]
---

# Sorcerer

## Realm

- [[Essence]]

## Spell Lists

- [[Soul Destruction]]
- [[Fluid Destruction]]
- [[Solid Destruction]]
- [[Mind Destruction]]
- [[Flesh Destruction]]
- [[Gas Destruction]]

## Mana World Notes

TODO: Add how Sorcerer fits into Aethergate and the mana-rationing world.
