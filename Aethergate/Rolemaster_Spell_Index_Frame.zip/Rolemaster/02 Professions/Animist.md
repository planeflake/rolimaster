---
type: profession
profession: "Animist"
realm: Channeling
system: Rolemaster
tags: [rolemaster, profession, channeling]
---

# Animist

## Realm

- [[Channeling]]

## Spell Lists

- [[Nature's Movement]]
- [[Plant Mastery]]
- [[Animal Mastery]]
- [[Herb Mastery]]
- [[Nature's Protection]]
- [[Nature's Lore]]

## Mana World Notes

TODO: Add how Animist fits into Aethergate and the mana-rationing world.
