---
type: profession
profession: "Evil Mentalist"
realm: Mentalism
system: Rolemaster
tags: [rolemaster, profession, mentalism]
---

# Evil Mentalist

## Realm

- [[Mentalism]]

## Spell Lists

- [[Mind Subversion]]
- [[Mind Domination]]
- [[Mind Erosion]]
- [[Mind Death]]
- [[Mind Disease]]

## Mana World Notes

TODO: Add how Evil Mentalist fits into Aethergate and the mana-rationing world.
