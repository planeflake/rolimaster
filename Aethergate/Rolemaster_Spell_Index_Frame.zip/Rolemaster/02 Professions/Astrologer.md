---
type: profession
profession: "Astrologer"
realm: Channeling
system: Rolemaster
tags: [rolemaster, profession, channeling]
---

# Astrologer

## Realm

- [[Channeling]]

## Spell Lists

- [[Way of the Voice]]
- [[Holy Vision]]
- [[Far Voice]]
- [[Starsense]]
- [[Time's Bridge]]
- [[Starlights]]

## Mana World Notes

TODO: Add how Astrologer fits into Aethergate and the mana-rationing world.
