---
type: profession
profession: "Seer"
realm: Mentalism
system: Rolemaster
tags: [rolemaster, profession, mentalism]
---

# Seer

## Realm

- [[Mentalism]]

## Spell Lists

- [[True Sight]]
- [[True Perception]]
- [[Mind Visions]]
- [[Sense Through Others]]
- [[Past Visions]]
- [[Future Visions]]

## Mana World Notes

TODO: Add how Seer fits into Aethergate and the mana-rationing world.
