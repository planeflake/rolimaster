---
type: profession
profession: "Mystic"
realm: Mentalism
system: Rolemaster
tags: [rolemaster, profession, mentalism]
---

# Mystic

## Realm

- [[Mentalism]]

## Spell Lists

- [[Confusing Ways]]
- [[Hiding]]
- [[Mystical Change]]
- [[Liquid Alteration]]
- [[Solid Alteration]]
- [[Gas Alteration]]

## Mana World Notes

TODO: Add how Mystic fits into Aethergate and the mana-rationing world.
