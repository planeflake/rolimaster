# Mana Economy

Mana is harvested, refined, transported and regulated.