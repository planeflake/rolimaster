---
type: profession
realm: Channeling
---

# Cleric

## Base Lists

- [[Rituals]]
- [[Channels]]
- [[Communal Ways]]
- [[Protections]]
- [[Summons]]
- [[Life Mastery]]

## Open Lists

- [[Barrier Law]]
- [[Detection Mastery]]
- [[Weather Ways]]
- [[Purifications]]
- [[Spell Defense]]
- [[Lufty Movements]]
- [[Light's Way]]
- [[Sound's Way]]
- [[Nature's Law]]
- [[Concussion's Ways]]
