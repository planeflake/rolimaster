# Spell Lists Index

## Channeling

### Open Channeling

- [[Open Channeling Index]]

### Closed Channeling

- [[Closed Channeling Index]]
