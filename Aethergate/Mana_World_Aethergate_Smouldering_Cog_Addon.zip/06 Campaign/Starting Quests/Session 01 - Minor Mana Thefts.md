---
type: session
campaign_stage: starting
location: The Smouldering Cog
city: Aethergate
tags:
  - session
  - starting-quest
  - mana-theft
---

# Session 01 - Minor Mana Thefts

## Opening Scene

The party begins inside [[The Smouldering Cog]], a tavern built into the shell of one of [[Aetherspark, Architect of the Currents|Aetherspark's]] failed flying boats.

The common room is busy. Pipeline workers argue over pressure readings. Airship crews drink before departure. A junior artificer demonstrates a tiny clockwork bird that repeatedly crashes into soup bowls.

Outside, Aethergate's mana lamps flicker.

Inside, everyone notices.

## Inciting Incident

A small mana canister hidden beneath the tavern bar begins to overheat.

It was planted there by a frightened runner connected to recent thefts.

Before it explodes, the party can notice:

- A rising orange glow beneath the bar
- A high-pitched boiler whistle
- Mara Cogswain becoming suddenly alarmed
- Drinks vibrating on nearby tables

## Possible Resolutions

- Cool the canister safely.
- Throw it into the street before detonation.
- Use magic to vent the mana.
- Evacuate the tavern.
- Fail, causing a minor explosion and panic.

## Aftermath

[[Inspector Elara Voss]] arrives with Mana Authority officers.

She quickly realizes this was not a normal tavern accident.

The canister residue does not match registered mana supplies.

## Clues

- The canister bears a scratched-off official seal.
- A residue trail leads toward the Engine Shrine.
- [[Pip Brasswhistle]] recognizes the canister.
- Bronn Gearwright identifies the resonance as "wrong."
- Someone in the tavern quietly leaves during the confusion.

## Main Suspects

- Pip Brasswhistle, frightened runner
- Unknown buyer with blue scarf and burn scar
- Pipeline workers with gambling debts
- A smuggling crew recently arrived from Tideglass

## Session Goal

By the end of the session, the party should have reason to investigate the missing mana canisters and the local pipeline thefts.

## Link Forward

- [[Session 02 - Pipeline Investigation]]
- [[The Underworks]]
- [[The Great Siphoning]]
