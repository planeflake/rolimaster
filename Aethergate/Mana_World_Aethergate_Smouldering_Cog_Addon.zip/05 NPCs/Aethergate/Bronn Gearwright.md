---
type: npc
organisation: Guild of Conduits
city: Aethergate
role: pipeline engineer
tags:
  - npc
  - engineer
  - conduit-guild
---

# Bronn Gearwright

## Overview

Master Engineer Bronn Gearwright is a senior pipeline engineer in Aethergate's Guild of Conduits.

He has spent forty years listening to pipes and claims he can tell the difference between pressure loss, sabotage, and "something drinking from the line."

Most people think he is being dramatic.

He is not.

## Appearance

- Broad dwarf
- Burn-scarred hands
- Copper ear-horn used for listening to conduits
- Beard tied with brass pressure tags

## What He Knows

- The recent losses do not behave like normal thefts.
- Some conduits arrive under pressure but with reduced resonance.
- A few readings suggest mana is being pulled away before reaching the surface lines.
- The old schematics beneath [[The Smouldering Cog]] do not match modern maps.

## Useful Dialogue

> "Pipes don't lie. People lie. Pipes scream."

> "If mana goes missing after the valve, that's theft. If it goes missing before the valve, that's a nightmare."
