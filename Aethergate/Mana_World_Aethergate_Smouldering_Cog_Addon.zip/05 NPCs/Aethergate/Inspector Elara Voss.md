---
type: npc
organisation: Mana Authority
city: Aethergate
role: investigator
tags:
  - npc
  - mana-authority
  - quest-giver
---

# Inspector Elara Voss

## Overview

Inspector Elara Voss is a [[Mana Authority]] investigator assigned to a cluster of minor mana thefts in [[Aethergate]].

She is competent, exhausted, and under pressure to treat the case as routine street crime.

## Personality

- Calm under pressure
- Dislikes theatrical adventurers
- Respects useful evidence
- Deeply suspicious of convenient answers

## Starting Use

Elara can hire or pressure the party into helping after trouble breaks out at [[The Smouldering Cog]].

## What She Suspects

The thefts are too small to interest major criminals, but too coordinated to be random.

Someone is testing the city's mana distribution system.

## Useful Dialogue

> "One stolen canister is theft. Twelve stolen canisters across six districts is infrastructure probing."

> "I do not need heroes. I need people who can follow evidence without setting fire to it."

## Links

- [[Session 01 - Minor Mana Thefts]]
- [[The Smouldering Cog]]
- [[Mana Authority]]
