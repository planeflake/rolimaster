---
type: npc
location: The Smouldering Cog
city: Aethergate
role: street runner
tags:
  - npc
  - informant
  - starting-quest
---

# Pip Brasswhistle

## Overview

Pip is a young street runner who delivers messages, food, spare parts, and occasionally things he knows better than to ask about.

He is quick, nervous, and knows half the backways in [[Cogmarket]].

## Appearance

- Teenager
- Oversized coat
- Goggles usually worn on forehead
- Carries a battered tin whistle
- Always eating something

## Personality

Pip talks fast, lies badly, and runs very well.

He wants to seem like a hardened street operator but is clearly scared by the mana thefts.

## Connection to the Starting Quest

Pip unknowingly delivered small mana canisters to a middleman connected to the thefts.

He thought they were faulty condenser parts.

## What He Knows

- The packages were always warm.
- The buyer wore a blue scarf and had a burn scar on one cheek.
- Deliveries were left near an old pressure hatch below [[The Smouldering Cog]].
- He once heard someone mention "the Deep Route."

## Secret

Pip stole one small cracked mana vial and hid it in the tavern's Engine Shrine.

He does not know it contains unstable siphoned mana.
