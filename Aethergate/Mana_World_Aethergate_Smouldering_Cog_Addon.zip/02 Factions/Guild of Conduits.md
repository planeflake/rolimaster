---
type: organisation
city: Aethergate
role: infrastructure guild
tags:
  - faction
  - guild
  - pipelines
---

# Guild of Conduits

## Overview

The Guild of Conduits maintains Aethergate's mana pipelines, pressure valves, reservoirs, and distribution lines.

They are practical, stubborn, and deeply proud of their work.

## Public Role

- Repair pipeline leaks
- Monitor city mana pressure
- Maintain safety valves
- Train conduit engineers
- Investigate infrastructure faults

## Important NPCs

- [[Bronn Gearwright]]

## Current Problem

The Guild has noticed pressure and resonance losses that do not match normal leaks or thefts.

Their reports are being ignored by officials who prefer simpler explanations.

## Relationship with Other Groups

- Works with the [[Mana Authority]]
- Distrusts the Refiners Consortium
- Drinks heavily at [[The Smouldering Cog]]
